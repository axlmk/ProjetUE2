#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "exiaImage.h"
#include <string.h>


//char* nomFichierParDefaut = "/home/exiasaver/Documents/PBM/maison.pbm"; // windows only


int main(int argc, char** argv)
{
    char* nomFichierImage;//= argv[1];
    if(argc > 1)
        nomFichierImage = argv[1]; // <=> *(argv +1)
    ExiaImage imgConsole;
    imgConsole.resX = 80;
    imgConsole.resY = 24;
    allouerImage(&imgConsole);
    ExiaImage img;
    lireFichier(&img, nomFichierImage);

    int posX = imgConsole.resX/2; // centre de console
    int posY = imgConsole.resY/2; // centre de console
    while(1)
        {
        initialiserContenu(&imgConsole,' ');
        centrerImageDans(&imgConsole, &img, posX, posY );
        afficherImage(&imgConsole);
        char c;
        c = getchar();
        if(c=='q')
            return 0;
        }
}
