#ifndef EXIASAVER_H_INCLUDED
#define EXIASAVER_H_INCLUDED

int chiffreRandom (int n);
char selectionImage (int n);
struct tm heure ();

#endif // EXIASAVER_H_INCLUDED
