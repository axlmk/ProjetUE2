#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "exiaImage.h"
#include <string.h>


char* nomFichierParDefaut = "bas.pbm";
/*char* imageBas = "/home/exiasaver/Documents/PBM/bas.pbm";
char* imageHaut = "/home/exiasaver/Documents/PBM/haut.pbm";
char* imageDroite = "/home/exiasaver/Documents/PBM/droite.pbm";
char* imageGauche = "/home/exiasaver/Documents/PBM/gauche.pbm";*/
int main(int argc, char** argv)
{
    char* nomFichierImage = nomFichierParDefaut;
    if(argc > 1)
        nomFichierImage = argv[1]; // <=> *(argv +1)
    ExiaImage imgConsole;
    imgConsole.resX = 80;
    imgConsole.resY = 24;
    allouerImage(&imgConsole);
    ExiaImage img;
    lireFichier(&img, nomFichierImage);

    int posX = imgConsole.resX/2; // centre de console
    int posY = imgConsole.resY/2; // centre de console
    while(1)
        {
        initialiserContenu(&imgConsole,' ');
        centrerImageDans(&imgConsole, &img, posX, posY );
        afficherImage(&imgConsole);
        char c;
        c = getchar();
         if(c=='h')      // haut
            posY--;
        if(c=='b')      // bas
            posY++;
        if(c=='d')      // droite
            posX++;
        if(c=='g')      // gauche
            posX--;
        if(c=='p')      // quitter
            return 0;
        }

}
