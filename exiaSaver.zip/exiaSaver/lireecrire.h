#ifndef LIREECRIRE_H_INCLUDED
#define LIREECRIRE_H_INCLUDED

void ecrire(int type, char image[]);
//struct tm heure ();
void lire ();

#endif // LIREECRIRE_H_INCLUDED
