#ifndef TRAITEMENTPBM_H_INCLUDED
#define TRAITEMENTPBM_H_INCLUDED
#include "traitementStructure.h"

fichierPBM creeStructure();
fichierPBM addition(fichierPBM fUN, fichierPBM fDEUX);
fichierPBM changerStructure(fichierPBM fPBM);

#endif // TRAITEMENTPBM_H_INCLUDED
