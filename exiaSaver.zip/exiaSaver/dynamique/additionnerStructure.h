#ifndef ADDITIONNERSTRUCTURE_H_INCLUDED
#define ADDITIONNERSTRUCTURE_H_INCLUDED
#include "structureFichierPBM.h"

fichierPBM creeStructure();
fichierPBM addition(fichierPBM fUN, fichierPBM fDEUX);
fichierPBM changerStructure(fichierPBM fPBM);

#endif // ADDITIONNERSTRUCTURE_H_INCLUDED
