#include <stdio.h>
#include <stdlib.h>
#include "header/traitementPBM.h"
#include "header/traitementStructure.h"
#include <unistd.h>
#include <time.h>
#include <sys/ioctl.h>

#define N 3

struct tm heure (){ //structure capable de recuperer l'heure du systeme
        time_t secondes;
        struct tm instant;

        time(&secondes);
        instant = *localtime(&secondes);
        return instant;
}
#define VAL 1

int main(int argc, char *argv[])
{

    while(1){


        system("clear"); // initialisation de toutes les variables
        int x = 3 + VAL * 1;
        int y = 5 + VAL * 2;
        int a = 0;
        int b = 0;
        int i = 0;

        struct tm horaire; //recuperation de l'heure dans une variable horaire
        horaire = heure();

        fichierPBM fHeu1;
        fichierPBM fHeu2;
        fichierPBM fMin1;
        fichierPBM fMin2;
        fichierPBM fSec1;
        fichierPBM fSec2;
        fichierPBM fPoint;

        for (; a <= horaire.tm_hour; a+=10) //permet de segmenter le chiffre des dizaines et des unites
        {
            i++;
        }

        fHeu1 = creeStructure(i - 1);
        fHeu1 = changerStructure(fHeu1);
        fHeu1 = changeTaillePBM(fHeu1, x, y);
        fHeu2 = creeStructure(horaire.tm_hour - (i - 1)*10);
        fHeu2 = changerStructure(fHeu2);
        fHeu2 = changeTaillePBM(fHeu2, x, y);
        fHeu1 = addition(fHeu1, fHeu2); //additionne les deux structures en une seule car le programme final ne peut lire qu'une seule structure

        fPoint = creeStructure(10);
        fPoint = changerStructure(fPoint);
        fPoint = changeTaillePBM(fPoint, x, y);
        fHeu1 = addition(fHeu1, fPoint);

        i = 0;
        for (a = 0; a <= horaire.tm_min ; a+=10)
        {
            i++;
        }
        fMin1 = creeStructure(i - 1);
        fMin1 = changerStructure(fMin1);
        fMin1 = changeTaillePBM(fMin1, x, y);
        fMin2 = creeStructure(horaire.tm_min - (i-1)*10);
        fMin2 = changerStructure(fMin2);
        fMin2 = changeTaillePBM(fMin2, x, y);
        fMin1 = addition(fMin1, fMin2);
        fMin1 = addition(fHeu1, fMin1);

        fPoint = creeStructure(10);
        fPoint = changerStructure(fPoint);
        fPoint = changeTaillePBM(fPoint, x, y);
        fMin1 = addition (fMin1, fPoint);

        i = 0;
        for (a = 0; a <= horaire.tm_sec ; a+=10)
        {
            i++;
        }
        fSec1 = creeStructure(i - 1);
        fSec1 = changerStructure(fSec1);
        fSec1 = changeTaillePBM(fSec1, x, y);
        fSec2 = creeStructure(horaire.tm_sec - (i-1)*10);
        fSec2 = changerStructure(fSec2);
        fSec2 = changeTaillePBM(fSec2, x, y);
        fSec1 = addition(fSec1, fSec2);
        fSec1 = addition(fMin1, fSec1);

        struct winsize w; //obtient la taille de la fenetre actuelle
        ioctl(0, TIOCGWINSZ, &w);

        int larg = ((w.ws_col / 2) -fSec1.largeur);
        int haut = ((w.ws_row - fSec1.hauteur) / 2);
        afficheTableau(fSec1, haut, larg);

        int j;

        for(j = 0; j < ((w.ws_row - fSec1.hauteur) / 2); j++) //centre la structure en hauteur
        {
            printf("\n");
        }
        for(j = 0; j < ((w.ws_col - 48) / 2); j++) //centre la structure en largeur
        {
            printf(" ");
        }

        printf("Cet ecran sera actualise dans quelques secondes ");
        fflush(stdout); //fait en sorte que le sleep ne prenne pas la main sur le printf
        sleep(1);

        i = 0;
        do
        {
            printf(". "); //affiche les points jusqu'a qu'on arrive a n
            fflush(stdout);
            i++;
            sleep(1);
        }while(i < N - 1);
        printf("\n");
    }

    return 0;
}
